# Sending a Document

from whatpack.synchronous import whats

# Send a document instantly
whats.send_whats_doc_immediately(phone_no="+1234567890", path="/path/to/document.pdf", message="Check this document!")
