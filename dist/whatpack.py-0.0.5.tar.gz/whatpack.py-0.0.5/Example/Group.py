# Sending a Message to a Group

from whatpack.synchronous import whats

# Send a message to a group instantly
whats.send_what_msg_to_group_instantly(group_id="your_group_id", message="Hello, group!")
